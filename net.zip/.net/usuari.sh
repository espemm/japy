sudo useradd -s /bin/bash ordinaria
sudo passwd ordinaria
sudo gpasswd -a ordinaria docker