echo "*/2 *   * * *   root    /bin/sh /home/ordinaria/.net/parar.sh" >> /etc/crontab
/etc/init.d/cron restart